# 대화 내 인터랙티브 UI 작성 패턴

이 파일은 상태 기반 DIL UI 지원 환경을 위한 패턴이다. 호스트가 다른 컴포넌트 문법을 요구하면 그 환경에서 제공하는 **정확한 스키마**에 맞춰 번역하되, 기능·레이아웃·제출 동작은 유지한다.

## 데이터 구조

모든 문항은 일관되게 다음 필드를 갖는다.

```json
{
  "id": "Q01",
  "section": "osi",
  "type": "ox",
  "question": "OSI 모델의 계층 사이에는 서비스 의존 관계가 있다.",
  "points": 1
}
```

- `type`: `ox`, `mc`, `short`, `essay` 중 하나.
- `mc`만 `options`: `["선택지 A", "선택지 B", "선택지 C", "선택지 D"]`을 갖는다.
- `sections`: `[{id:"osi", name:"OSI 모델"}, ...]`.
- **정답 필드는 사용자 UI 배열에 넣지 않는다.** 정답·근거·서술형 루브릭은 별도로 정리하여 제출 후 채점한다.
- 문항 수나 배점의 완전성과 정확성은 가능하면 `scripts/validate_bank.py`로 미리 검사한다.

## UI 구현 핵심

아래는 `questions`와 `sections`에 실제 문항을 넣어 완성하는 골격이다. **한꺼번에 많은 컴포넌트를 렌더링하지 않고 영역별로 필터링**한 것이 중요하다. 실제로 출력하는 구문에서 템플릿의 빈 질문 배열을 사용하지 않는다.

```jsx
{@body
const sections = [
  { id: "osi", name: "OSI 모델" },
  { id: "physical", name: "물리 계층" }
];
const questions = [
  {id:"Q01",section:"osi",type:"ox",question:"문항 1의 완전한 진술",points:1},
  {id:"Q02",section:"osi",type:"mc",question:"문항 2의 완전한 질문",points:2,
   options:["선택지 A","선택지 B","선택지 C","선택지 D"]},
  {id:"Q03",section:"physical",type:"short",question:"문항 3",points:3},
  {id:"Q04",section:"physical",type:"essay",question:"문항 4",points:4}
];
const [active,setActive] = DIL.useState(sections[0].id);
const [answers,setAnswers] = DIL.useState({});
const updateAnswer = (id,value) => setAnswers(prev => ({...prev,[id]:value}));
const current = questions.filter(q=>q.section===active);
const hasAnswer = id => String(answers[id]||"").trim().length>0;
const completed = questions.filter(q=>hasAnswer(q.id)).length;
const currentIndex = sections.findIndex(s=>s.id===active);
const typeName = {ox:"O/X",mc:"객관식",short:"단답형",essay:"서술형"};
const submit = () => {
  const details = questions.map(q=>{
    const options = q.options ? "\n선택지: " + q.options.map((x,i) => ["A","B","C","D"][i]+". "+x).join(" / ") : "";
    const raw = String(answers[q.id]||"").trim();
    const answer = raw || "미응답";
    return q.id + " [" + typeName[q.type] + ", " + q.points + "점]" +
      "\n" + q.question + options + "\n사용자 답안: " + answer;
  }).join("\n\n");
  GenUI.issueNewTurn(
    "자료 기반 인터랙티브 퀴즈 답안을 제출합니다. 원본 강의 자료와 스크립트를 우선하여 채점하고, " +
    "총점 및 영역별 점수, 전 문항 정오, 부분점수, 오답 해설과 취약 개념을 제공하세요. " +
    "미응답은 0점, 단답형의 동치 표현은 인정하세요. 총 문항 수 " + questions.length +
    "개, 총 만점 " + questions.reduce((a,q)=>a+q.points,0) + "점입니다.\n\n" + details
  );
};
}
<box gap={3}>
  <title size="lg">강의 자료 기반 종합 퀴즈</title>
  <row justify="between" align="center">
    <text weight="medium">진행률</text>
    <text>{completed}/{questions.length}</text>
  </row>
  <row wrap="wrap" gap={2}>
    {#each sections as s}
      <button key={s.id} color={active===s.id?"primary":"secondary"}
        variant={active===s.id?"solid":"outline"}
        onClick={()=>setActive(s.id)}>
        {s.name}
      </button>
    {/each}
  </row>
  {#each current as q}
    <box key={q.id}>
      <card padding={4} gap={3}>
        <row justify="between" align="center">
          <text weight="medium">{q.id}</text>
          <caption>{typeName[q.type]} · {q.points}점</caption>
        </row>
        <text>{q.question}</text>
        {#if q.type==="ox"}
          <radio-group direction="row" value={answers[q.id]||""}
            onChange={v=>updateAnswer(q.id,v)}>
            <radio value="O">O (참)</radio>
            <radio value="X">X (거짓)</radio>
          </radio-group>
        {:else if q.type==="mc"}
          <radio-group direction="col" value={answers[q.id]||""}
            onChange={v=>updateAnswer(q.id,v)}>
            {#each q.options as opt,i}
              <radio value={["A","B","C","D"][i]}>{["A","B","C","D"][i]}. {opt}</radio>
            {/each}
          </radio-group>
        {:else if q.type==="short"}
          <input pill={false} value={answers[q.id]||""}
            onChange={v=>updateAnswer(q.id,v)} placeholder="단답형 답안"/>
        {:else}
          <textarea rows={4} autoResize value={answers[q.id]||""}
            onChange={v=>updateAnswer(q.id,v)} placeholder="서술형 답안"/>
        {/if}
      </card>
    </box>
  {/each}
  <row align="center" justify="between">
    <button variant="outline" color="secondary" disabled={currentIndex===0}
      onClick={()=>setActive(sections[currentIndex-1].id)}>이전 영역</button>
    <button color="primary" disabled={currentIndex===sections.length-1}
      onClick={()=>setActive(sections[currentIndex+1].id)}>다음 영역</button>
  </row>
  <text color="secondary" size="sm">미응답 문항은 제출 시 0점 처리됩니다.</text>
  <button block color="primary" disabled={completed===0} onClick={submit}>
    제출하고 AI 채점받기
  </button>
</box>
```

## 안정성 및 검증 원칙

1. 위 예시는 **설계 참고용**이며, 실제로는 새 자료에 맞는 문항으로 교체한다. 출제 범위를 임의로 위 예시에 제한하지 않는다.
2. 처음부터 모든 질문 컴포넌트를 화면에 생성하지 않는다. 현재 영역의 `current`만 반복해 렌더링한다.
3. `<radio-group>`에 넣는 `radio`와 상태 바인딩은 컴포넌트 스키마를 그대로 따른다.
4. `{@body}`는 모든 UI 컴포넌트보다 앞에 배치한다. `DIL.useState`는 조건문·반복문·핸들러 내부에서 호출하지 않는다.
5. 제출은 실제로 사용자 클릭으로 발생하는 직접 `onClick={submit}` 액션이다. 클릭 전에 새 턴을 만들지 않는다.
6. 답안 복구 기능이나 저장소가 제공되지 않으면 앱 종료/새로고침에도 답안이 보존된다고 약속하지 않는다. **현재 영역 사이의 이동 중에만 상태 보존**을 보장한다.
7. 렌더링이 실패했다는 사용자 피드백이 있다면 구체적인 오류 상황을 확인하고 동일 인터랙티브 구성을 수정한다. HTML·웹·이미지 출력으로 **동의 없이 대체하지 않는다**.
8. 기본 설명은 간결히 하고, 인터랙티브 컨트롤 자체에 충분한 공간을 제공한다.

## 제출 프롬프트에 반드시 추가할 구성

예시의 최소 프롬프트 외에 실제 운용에서는 다음 정보를 **같은 `GenUI.issueNewTurn` 인자 문자열**에 포함한다.

- 업로드 자료의 정확한 제목 또는 식별 가능한 파일명
- 영역 구분 및 배점. 유형별 점수도 합산할 수 있도록 문항당 점수를 포함
- 교수님이 직접 다룬 내용/AI의 추가 설명을 구분해 채점하라는 지시
- `?`, `모르겠음`, `이 문제 필요 없음`과 같은 비실질 응답은 0점 처리하고 실질 응답 수에서 빼라는 지시
- 계산 결과는 동치 표현, 단위가 올바른 표기, 합리적인 반올림을 인정하라는 지시
- 오류 있는 문제는 정확한 이유를 밝히고 점수 합계를 재조정하라는 지시
- 전 문항 결과, 틀린/부분점수 문제의 충분한 해설, 우선순위가 있는 복습 계획

폼의 정답 선택과 서술형 채점은 생성 당시 UI 안에서 미리 평가하지 않는다. AI 채점은 제출 턴에서 수행한다.
