#!/usr/bin/env python3
"""Validate structure and point totals of an interactive source-based quiz bank.

Usage:
    python scripts/validate_bank.py /path/to/bank.json

Example bank shape:
    {"title":"Lecture quiz", "sections":[{"id":"intro","name":"Introduction"}],
     "questions":[{"id":"Q01","section":"intro","type":"ox",
                   "question":"A complete assertion.","points":1}]}

The file is a draft question bank and MUST NOT contain answer keys or source secrets.
"""
import collections
import json
import pathlib
import re
import sys

TYPES = {"ox", "mc", "short", "essay"}


def validate(bank):
    errors = []
    if not isinstance(bank, dict):
        return ["The root must be a JSON object."], None
    sections = bank.get("sections", [])
    questions = bank.get("questions", [])
    if not isinstance(sections, list) or not sections:
        errors.append("sections must be a nonempty array")
        sections = []
    if not isinstance(questions, list) or not questions:
        errors.append("questions must be a nonempty array")
        questions = []
    section_ids = set()
    for idx, sec in enumerate(sections, start=1):
        if not isinstance(sec, dict) or not isinstance(sec.get("id"), str) or not sec["id"].strip():
            errors.append(f"sections[{idx}] needs a nonempty string id")
            continue
        if sec["id"] in section_ids:
            errors.append(f"duplicate section id: {sec['id']}")
        section_ids.add(sec["id"])
        if not isinstance(sec.get("name"), str) or not sec["name"].strip():
            errors.append(f"sections[{idx}] needs a nonempty name")
    ids = set()
    count = collections.Counter()
    point_by_type = collections.Counter()
    point_by_section = collections.Counter()
    for idx, q in enumerate(questions, start=1):
        path = f"questions[{idx}]"
        if not isinstance(q, dict):
            errors.append(f"{path} must be an object")
            continue
        qid = q.get("id")
        if not isinstance(qid, str) or not re.fullmatch(r"Q\d{2,4}", qid):
            errors.append(f"{path} id must look like Q01")
        elif qid in ids:
            errors.append(f"duplicate question id: {qid}")
        else:
            ids.add(qid)
        sec = q.get("section")
        if sec not in section_ids:
            errors.append(f"{path} references unknown section: {sec!r}")
        kind = q.get("type")
        if kind not in TYPES:
            errors.append(f"{path} type must be one of {sorted(TYPES)}")
        if not isinstance(q.get("question"), str) or len(q["question"].strip()) < 5:
            errors.append(f"{path} needs a substantive question")
        pts = q.get("points")
        if isinstance(pts, bool) or not isinstance(pts, int) or pts <= 0:
            errors.append(f"{path} points must be a positive integer")
        else:
            count[kind] += 1
            point_by_type[kind] += pts
            point_by_section[sec] += pts
        if kind == "mc":
            opts = q.get("options")
            if not isinstance(opts, list) or len(opts) != 4 or any(not isinstance(o, str) or not o.strip() for o in opts):
                errors.append(f"{path} multiple choice requires four nonempty strings")
            elif len(set(o.strip() for o in opts)) != 4:
                errors.append(f"{path} has duplicate multiple choice options")
        elif "options" in q:
            errors.append(f"{path} may not carry options unless type is mc")
        if any(k in q for k in ("correct", "correctValues", "answer_key", "answerKey", "solution")):
            errors.append(f"{path} must not expose answer keys in the UI question bank")
    total = sum(point_by_type.values())
    expected_total = bank.get("total_points", 100)
    if isinstance(expected_total, bool) or not isinstance(expected_total, int) or expected_total <= 0:
        errors.append("total_points must be a positive integer")
    elif total != expected_total:
        errors.append(f"point total mismatch: declared {expected_total}, calculated {total}")
    if not TYPES.issubset(count):
        errors.append("quiz must contain all four formats: ox, mc, short, essay")
    summary = {
        "questions": len(questions), "calculated_points": total,
        "by_type": {t: {"questions": count[t], "points": point_by_type[t]} for t in sorted(TYPES)},
        "by_section": dict(point_by_section)
    }
    return errors, summary


def main():
    if len(sys.argv) != 2:
        print("Usage: validate_bank.py bank.json", file=sys.stderr)
        return 2
    path = pathlib.Path(sys.argv[1])
    try:
        bank = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"Unable to read quiz bank: {exc}", file=sys.stderr)
        return 2
    errors, summary = validate(bank)
    if summary:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    if errors:
        print("\nINVALID:", file=sys.stderr)
        for err in errors:
            print(f" - {err}", file=sys.stderr)
        return 1
    print("VALID: bank structure and point totals checked (answer correctness not verified)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
